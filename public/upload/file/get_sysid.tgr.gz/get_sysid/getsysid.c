#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <openssl/md5.h>
#include <linux/sockios.h>
#include <linux/if.h>
#include <arpa/inet.h>

#define MAC_LEN	12
#define SIOCGIFPHYSICALHWADDR	0x8952
#define MD5_DIGEST_LENGTH 16
#define __DEBUG printf


static char * lladdr_n2a (unsigned char *addr, int alen, int type, char *buf, int blen)
{
	int i;
	int l;
	if (alen == 4)
	{
		return (char *)inet_ntop (AF_INET, addr, buf, blen);
	}
	l = 0;
	for (i = 0; i < alen; i++)
	{
		if (i == 0)
		{
			snprintf (buf + l, blen, "%02x", addr[i]);
			blen -= 2;
			l += 2;
		}
		else
		{
			snprintf (buf + l, blen, ":%02x", addr[i]);
			blen -= 3;
			l += 3;
		}
	}
	return buf;
}


	static int
get_nic_mac(char *dev, char mac[MAC_LEN])
{
	int s;
	struct ifreq ifr;
	char *tmp = NULL;
	char b1[64] = {0};
	char mac_buffer[18] = {0};
	char zero_mac[8] = {0};
	memset(zero_mac, 0, sizeof(zero_mac));

	if(NULL ==dev || NULL == mac)
		return -1;

	strncpy (ifr.ifr_name, dev, sizeof(ifr.ifr_name));
	ifr.ifr_addr.sa_family = AF_INET;

	if ((s = socket(PF_INET,SOCK_DGRAM,0)) < 0)
		return -1;

	if (ioctl (s, SIOCGIFPHYSICALHWADDR, &ifr) < 0){
		if(ioctl (s, SIOCGIFHWADDR, &ifr) < 0){
			close (s);
			return -1;
		}
	}

	if(memcmp(ifr.ifr_hwaddr.sa_data, zero_mac, sizeof(zero_mac)) == 0){
		if(ioctl (s, SIOCGIFHWADDR, &ifr) < 0){
			close (s);
			return -1;
		}
	}

	close (s);

	lladdr_n2a ((unsigned char *) ifr.ifr_hwaddr.sa_data, 14, AF_INET, b1, sizeof (b1));

	strncpy (mac_buffer, b1, sizeof(mac_buffer));
	mac_buffer[17] = 0;
	//	__DEBUG("dev:%s mac:%s\n", dev, mac_buffer);
	mac[0]=mac_buffer[0];
	mac[1]=mac_buffer[1];

	mac[2]=mac_buffer[3];
	mac[3]=mac_buffer[4];

	mac[4]=mac_buffer[6];
	mac[5]=mac_buffer[7];

	mac[6]=mac_buffer[9];
	mac[7]=mac_buffer[10];

	mac[8]=mac_buffer[12];
	mac[9]=mac_buffer[13];

	mac[10]=mac_buffer[15];
	mac[11]=mac_buffer[16];
	mac[12] = 0;

	return 1;
}

int 
gen_license_sysID(unsigned char * sysID, int sysID_len)
{
	char mac[MAC_LEN] = {0};
	unsigned char md[MD5_DIGEST_LENGTH], *tmp_buffer=NULL;
	int tmp_buffer_len=0; 
	unsigned char tmp[32];
	char *t;
	t = tmp;

	if(NULL == sysID || sysID_len <32)
	{
		__DEBUG("invalid sysID or sysID_len.\n");
		return -1;
	}

	memset(mac, 0, sizeof(mac));
	if(get_nic_mac("eth0", mac)<0)
	{
		__DEBUG("get mac failed.\n");
		return -1;
	}

	if(!MD5(mac, sizeof(mac), md))
	{
		__DEBUG("MD5 failed.\n");
		return -1;
	}
	int i;
	for (i=0; i<16; i++)
	{
		sprintf(t,"%x",md[i]);
		t = t + 2;
	}
	memset(sysID, 0, sysID_len);
	memcpy(sysID, tmp, 32);
	return 1;
}

int main(int argc, char *argv[])
{
	char sysid[64] = {0};

	gen_license_sysID(sysid, 64);
	printf("%s\n", sysid);
	return 0;
}
